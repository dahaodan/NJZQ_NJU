import pandas as pd
import numpy as np
import statsmodels.api as sm
import math

import warnings
warnings.filterwarnings("ignore")

def stack2dataframe(df,index_nm,column_nm,feature_nm):
    """privot table"""
    return pd.pivot_table(
        df,
        index = index_nm,
        columns = column_nm,
        values = feature_nm).sort_index()

def get_weights(m,T,tn):
    w = m**(1/T)
    """生成weight序列"""
    w_list = np.array([w**(tn-1-i) for i in range(tn)])
    return w_list


def get_Njyr(end_date,N,df_date = df_date):
    return sorted((df_date[df_date['tradingdate']<=end_date]['tradingdate'].values))[-N:]


df_hq = pd.read_csv('result_20150328_20220328.csv')
df_hq.drop(['Unnamed: 0','adjustflag'],axis = 1,inplace = True)
df_hq.rename(columns = {'pctChg':'changepct','turn':'turnoverrate','date':'tradingday','code':'secucode'},inplace = True)
df_hq = df_hq[df_hq['amount']>0].copy()
market_dict = {
    'sh':['600','601','603','605','688'],
    'sz':['000','001','002','003','300','301']}

df_hq['secucategory'] = df_hq['secucode'].apply(lambda x: 1 if x.split('.')[1][:3] in market_dict[x.split('.')[0]] else 0)
df_hq['tradingday'] = df_hq['tradingday'].apply(lambda x:x.replace('-',''))
df_hq['secucode'] = df_hq['secucode'].apply(lambda x:x.split('.')[1])
df_300 = df_hq[df_hq['secucode']=='000300'].copy()
df_hq = df_hq[df_hq['secucategory']==1].copy()

df_date = pd.read_csv('tradingday.csv')
df_date['tradingdate'] = df_date['tradingdate'].astype(str)
# date_list = sorted([col for col in df_date['tradingdate'].unique() if col >='20210101' and '20211231'])
date_list = sorted([col for col in df_date['tradingdate'].unique() if col >='20210101' and col <='20211231'])

for dt in date_list:
    print(dt,'Begin=====')
    #dt = '20220328'
    df_res = df_hq[df_hq['tradingday']==dt][['tradingday','secucode']].copy()

    N = 252
    dt_list = get_Njyr(dt,N)
    turnoverrate = stack2dataframe(df_hq[(df_hq['tradingday'].isin(dt_list))].copy(),'tradingday','secucode','turnoverrate')
    w_list = get_weights(0.5,63,252)
    weights = turnoverrate.copy()
    weights.loc[:,:] = np.repeat(
        w_list.reshape(252,1),len(turnoverrate.columns),axis = 1)
    annualized_traded_value_ratio = (weights * turnoverrate ).rolling(252,min_periods = 1).sum()/np.sum(weights)
    annualized_traded_value_ratio = dict(annualized_traded_value_ratio.loc[dt,:])
    df_res['annualized_traded_value_ratio'] = df_res['secucode'].map(annualized_traded_value_ratio)

    """
    average_turnoverrate_1m: 计算过去21个交易日的换手率之和,
    average_turnoverrate_1q: 计算过去63个交易日的换手率之和,
    average_turnoverrate_1yr: 计算过去252个交易日的换手率之和,
    """
    N = 21
    dt_list = get_Njyr(dt,N)
    turnoverrate = stack2dataframe(df_hq[(df_hq['tradingday'].isin(dt_list))].copy(),'tradingday','secucode','turnoverrate')
    average_turnoverrate_1m = np.log(np.nansum(turnoverrate/100,axis = 0))
    average_turnoverrate_1m = {k:v for k,v in zip(turnoverrate.columns,average_turnoverrate_1m)}
    df_res['average_turnoverrate_1m'] = df_res['secucode'].map(average_turnoverrate_1m)

    N = 63
    dt_list = get_Njyr(dt,N)
    turnoverrate = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','turnoverrate')
    stom_list = []
    for i in range(0,N,21):
        stom = np.log(np.nansum(turnoverrate[turnoverrate.index[i]:turnoverrate.index[i+20]]/100,axis = 0))
        stom_list.append(stom)
    average_turnoverrate_1q = np.log(np.nanmean(np.exp(np.stack(stom_list,axis = 0)),axis = 0))
    average_turnoverrate_1q = {k:v for k,v in zip(turnoverrate.columns,average_turnoverrate_1q)}
    df_res['average_turnoverrate_1q'] = df_res['secucode'].map(average_turnoverrate_1q)

    N = 252
    dt_list = get_Njyr(dt,N)
    turnoverrate = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','turnoverrate')
    stom_list = []
    for i in range(0,N,21):
        stom = np.log(np.nansum(turnoverrate[turnoverrate.index[i]:turnoverrate.index[i+20]]/100,axis = 0))
        stom_list.append(stom)
    average_turnoverrate_1yr = np.log(np.nanmean(np.exp(np.stack(stom_list,axis = 0)),axis = 0))
    average_turnoverrate_1yr = {k:v for k,v in zip(turnoverrate.columns,average_turnoverrate_1yr)}

    df_res['average_turnoverrate_1yr'] = df_res['secucode'].map(average_turnoverrate_1yr)

    """
    daily_std_dec: 日收益率在过去252个交易日的波动率，半衰期42个交易日,
    """
    N = 252
    dt_list = get_Njyr(dt,N)
    changepct = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','changepct')/100
    changepct = changepct.fillna({k:v for k,v in zip(changepct.columns,np.nanmean(changepct,axis = 0))})
    """
    dastd = sqrt(sum(wi*(ri-avg(ri))^2))
    """
    w = (1/2)**(1/42)
    tn = 252
    """生成weight序列"""
    w_list = np.array([w**(tn-1-i) for i in range(tn)])
    weights = np.repeat(w_list.reshape(N,1),len(changepct.columns),axis = 1)
    daily_std_dec = (np.nansum((changepct.values - np.nanmean(changepct,axis = 0))**2  * weights,axis = 0)/\
    np.nansum(weights,axis = 0))**0.5

    daily_std_dec = {k:v for k,v in zip(changepct.columns,daily_std_dec)}

    df_res['daily_std_dec'] = df_res['secucode'].map(daily_std_dec)

    """hist_sigma: 在计算BETA所进行的时间序列回归中，取回归残差收益率的波动率,"""

    index_pct_list = np.array(df_300[df_300['tradingday'].isin(dt_list)].sort_values('tradingday')['changepct'])/100
    index_pct = np.repeat(index_pct_list.reshape(N,1),len(changepct.columns),axis = 1)
    x = changepct.values
    y = index_pct_list.copy()
    Y = sm.add_constant(y)
    model = sm.WLS(x,Y,w_list)
    result = model.fit()
    # alpha_ ,beta_  = result.params
    resid_ = result.resid
    hist_sigma = np.nanstd(resid_,axis = 0)
    hist_sigma = {k:v for k,v in zip(changepct.columns,hist_sigma)}

    df_res['hist_sigma'] = df_res['secucode'].map(hist_sigma)

    """
    beta_1y:
    股票收益率 对沪深300收益率，进行时间序列回归，取回归系数，回归时间窗口为252个交易日，半衰期63个交易日,
    historical_alpha:
    股票收益率 对沪深300收益率 进行时间序列回归，取截距项，回归时间窗口为252个交易日，半衰期63个交易日,
    """
    N = 252
    dt_list = get_Njyr(dt,N)
    changepct = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','changepct')/100
    changepct = changepct.fillna({k:v for k,v in zip(changepct.columns,np.nanmean(changepct,axis = 0))})
    w = 0.5**(1/63)
    tn = len(changepct.index)
    """生成weight序列"""
    w_list = np.array([w**(tn-1-i) for i in range(tn)])

    x = changepct.values
    y = index_pct_list.copy()
    Y = sm.add_constant(y)
    model = sm.WLS(x,Y,w_list)
    result = model.fit()
    alpha_ ,beta_  = result.params

    historical_alpha = {k:v for k,v in zip(changepct.columns,alpha_)}
    beta_1y = {k:v for k,v in zip(changepct.columns,beta_)}
    df_res['historical_alpha'] = df_res['secucode'].map(historical_alpha)
    df_res['beta_1y'] = df_res['secucode'].map(beta_1y)

    """
    decl_dr_wgt_mean_12_month: 最近n个月以每日换手率为权重，计算每日收益率的算术平均值，n=12，换手率随时间衰减,
    decl_dr_wgt_mean_6_month: 最近n个月以每日换手率为权重，计算每日收益率的算术平均值，n=6，换手率随时间衰减,
    """

    N = 6*20
    dt_list = get_Njyr(dt,N)

    turnoverrate = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','turnoverrate')
    changepct = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','changepct')/100
    w = (1/math.e)**(1/(120*4))
    tn = N

    """生成weight序列"""
    w_list = np.array([w**(tn-1-i) for i in range(tn)])

    weigths = turnoverrate.values * np.repeat(w_list.reshape(N,1),len(changepct.columns),axis =1)
    decl_dr_wgt_mean_6_month = np.nansum(weigths * changepct.values ,axis = 0)/np.nansum(weigths,axis = 0)
    decl_dr_wgt_mean_6_month = {k:v for k,v in zip(changepct.columns,decl_dr_wgt_mean_6_month)}

    df_res['decl_dr_wgt_mean_6_month'] = df_res['secucode'].map(decl_dr_wgt_mean_6_month)

    N = 12*20
    dt_list = get_Njyr(dt,N)

    turnoverrate = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','turnoverrate')
    changepct = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','changepct')/100

    w = (1/math.e)**(1/(N*4))
    tn = N
    """生成weight序列"""
    w_list = np.array([w**(tn-1-i) for i in range(tn)])
    weigths = turnoverrate.values * np.repeat(w_list.reshape(N,1),len(changepct.columns),axis =1)
    decl_dr_wgt_mean_12_month = np.nansum(weigths * changepct.values ,axis = 0)/np.nansum(weigths,axis = 0)
    decl_dr_wgt_mean_12_month = {k:v for k,v in zip(changepct.columns,decl_dr_wgt_mean_12_month)}

    df_res['decl_dr_wgt_mean_12_month'] = df_res['secucode'].map(decl_dr_wgt_mean_12_month)

    """
    dr_abs_mean_val_mean_12m: 过去12月收益率绝对值均值/成交额均值,
    dr_abs_mean_val_mean_1m: 过去1月收益率绝对值均值/成交额均值,
    dr_abs_mean_val_mean_3m: 过去3月收益率绝对值均值/成交额均值,
    dr_abs_mean_val_mean_6m: 过去6月收益率绝对值均值/成交额均值,
    """
    N = 12*20
    dt_list = get_Njyr(dt,N)

    turnovervalue = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','amount')/10000
    changepct = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','changepct')/100


    dr_abs_mean_val_mean_12m = np.nanmean(abs(changepct),axis = 0)*100000/np.nanmean(turnovervalue,axis = 0)
    dr_abs_mean_val_mean_12m = {k:v for k,v in zip(changepct.columns,dr_abs_mean_val_mean_12m)}
    df_res['dr_abs_mean_val_mean_12m'] = df_res['secucode'].map(dr_abs_mean_val_mean_12m)

    N = 1*20
    dt_list = get_Njyr(dt,N)

    turnovervalue = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','amount')/10000
    changepct = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','changepct')/100

    dr_abs_mean_val_mean_1m = np.nanmean(abs(changepct),axis = 0)*100000/np.nanmean(turnovervalue,axis = 0)
    dr_abs_mean_val_mean_1m = {k:v for k,v in zip(changepct.columns,dr_abs_mean_val_mean_1m)}

    df_res['dr_abs_mean_val_mean_1m'] = df_res['secucode'].map(dr_abs_mean_val_mean_1m)

    N = 3*20
    dt_list = get_Njyr(dt,N)

    turnovervalue = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','amount')/10000
    changepct = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','changepct')/100

    dr_abs_mean_val_mean_3m = np.nanmean(abs(changepct),axis = 0)*100000/np.nanmean(turnovervalue,axis = 0)
    dr_abs_mean_val_mean_3m = {k:v for k,v in zip(changepct.columns,dr_abs_mean_val_mean_3m)}

    df_res['dr_abs_mean_val_mean_3m'] = df_res['secucode'].map(dr_abs_mean_val_mean_3m)

    N = 6*20
    dt_list = get_Njyr(dt,N)

    turnovervalue = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','amount')/10000
    changepct = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','changepct')/100
    dr_abs_mean_val_mean_6m = np.nanmean(abs(changepct),axis = 0)*100000/np.nanmean(turnovervalue,axis = 0)
    dr_abs_mean_val_mean_6m = {k:v for k,v in zip(changepct.columns,dr_abs_mean_val_mean_6m)}

    df_res['dr_abs_mean_val_mean_6m'] = df_res['secucode'].map(dr_abs_mean_val_mean_6m)

    """
    turn_val_std_mean_12m: 过去12月成交额标准差/均值,
    turn_val_std_mean_1m: 过去1月成交额标准差/均值,
    turn_val_std_mean_3m: 过去3月成交额标准差/均值,
    turn_val_std_mean_6m: 过去6月成交额标准差/均值,
    """
    N = 12*20
    dt_list = get_Njyr(dt,N)

    turnovervalue = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','amount')/10000
    changepct = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','changepct')/100


    turn_val_std_mean_12m = np.nanstd(turnovervalue,ddof = 1,axis = 0) / np.nanmean(turnovervalue,axis = 0)
    turn_val_std_mean_12m = {k:v for k,v in zip(changepct.columns,turn_val_std_mean_12m)}

    df_res['turn_val_std_mean_12m'] = df_res['secucode'].map(turn_val_std_mean_12m)

    N = 1*20
    dt_list = get_Njyr(dt,N)

    turnovervalue = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','amount')/10000
    changepct = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','changepct')/100



    turn_val_std_mean_1m = np.nanstd(turnovervalue,ddof = 1,axis = 0) / np.nanmean(turnovervalue,axis = 0)
    turn_val_std_mean_1m = {k:v for k,v in zip(changepct.columns,turn_val_std_mean_1m)}

    df_res['turn_val_std_mean_1m'] = df_res['secucode'].map(turn_val_std_mean_1m)

    N = 3*20
    dt_list = get_Njyr(dt,N)

    turnovervalue = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','amount')/10000
    changepct = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','changepct')/100


    turn_val_std_mean_3m = np.nanstd(turnovervalue,ddof = 1,axis = 0) / np.nanmean(turnovervalue,axis = 0)
    turn_val_std_mean_3m = {k:v for k,v in zip(changepct.columns,turn_val_std_mean_3m)}

    df_res['turn_val_std_mean_3m'] = df_res['secucode'].map(turn_val_std_mean_3m)

    N = 6*20
    dt_list = get_Njyr(dt,N)

    turnovervalue = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','amount')/10000
    changepct = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','changepct')/100

    turn_val_std_mean_6m = np.nanstd(turnovervalue,ddof = 1,axis = 0) / np.nanmean(turnovervalue,axis = 0)
    turn_val_std_mean_6m = {k:v for k,v in zip(changepct.columns,turn_val_std_mean_6m)}

    df_res['turn_val_std_mean_6m'] = df_res['secucode'].map(turn_val_std_mean_6m)


    """
    std_12m: 过去12月日收益率标准差,
    std_3m: 过去3月日收益率标准差,
    std_6m: 过去6月日收益率标准差,
    """
    N = 12*20
    dt_list = get_Njyr(dt,N)
    changepct = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','changepct')/100
    std_12m = np.nanstd(changepct,ddof = 1,axis = 0)
    std_12m = {k:v for k,v in zip(changepct.columns,std_12m*100)}

    df_res['std_12m'] = df_res['secucode'].map(std_12m)

    N = 3*20
    dt_list = get_Njyr(dt,N)
    changepct = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','changepct')/100
    std_3m = np.nanstd(changepct,ddof = 1,axis = 0)
    std_3m = {k:v for k,v in zip(changepct.columns,std_3m*100)}

    df_res['std_3m'] = df_res['secucode'].map(std_3m)

    N = 6*20
    dt_list = get_Njyr(dt,N)
    changepct = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','changepct')/100
    std_6m = np.nanstd(changepct,ddof = 1,axis = 0)
    std_6m = {k:v for k,v in zip(changepct.columns,std_6m*100)}

    df_res['std_6m'] = df_res['secucode'].map(std_6m)

    """
    holding_return_1m: 最近21个交易日的累计持仓收益率,
    """
    N = 21
    dt_list = get_Njyr(dt,N)
    changepct = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','changepct')/100
    changepct_ = np.nancumprod(1+changepct,axis = 0)

    holding_return_1m = np.log(changepct_)[-1,:] -1
    holding_return_1m = {k:v for k,v in zip(changepct.columns,holding_return_1m)}

    df_res['holding_return_1m'] = df_res['secucode'].map(holding_return_1m)

    """
    relative_strength:
    1、计算非滞后的相对强度 对股票的对数收益率进行半衰指数加权求和，时间窗口252个交易日，半衰期126个交易日；
    2、以11个交易日为时间窗口，滞后11个交易日，取非滞后相对强度的等权平均值,
    """

    N = 252
    dt_list = get_Njyr(dt,N+11+11)


    changepct = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','changepct')/100

    changepct = np.log(1+ changepct)# 对数收益率
    w = (1/2)**(1/126)
    tn = N
    """生成weight序列"""
    w_list = np.array([w**(N-1-i) for i in range(N)])
    weights = np.repeat(w_list.reshape(N,1),len(changepct.columns),axis = 1)
    rs_list = []
    for i in range(11):
        rs = changepct.loc[changepct.index[-(252+11+i)]: changepct.index[-(12+i)]].values * weights
        rs_list.append(np.nansum(rs * 10000,axis = 0)/np.nansum(weights,axis = 0))

    relative_strength = np.nanmean(np.stack(rs_list,axis = 0),axis = 0)
    relative_strength = {k:v for k,v in zip(changepct.columns,relative_strength)}

    df_res['relative_strength'] = df_res['secucode'].map(relative_strength)

    """
    long_term_relative_strength:
    1、计算非滞后的长期相对强度，对股票对数收益率进行加权求和，时间窗口1040个交易日，半衰期260个交易日；
    2、滞后273个交易日，在11个交易日的时间窗口内取非滞后值等权平均值，最后取相反数,
    """
    N = 1040
    dt_list = get_Njyr(dt,N+11+273)
    changepct = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','changepct')/100
    changepct = np.log(1+ changepct)# 对数收益率

    w = (1/2)**(1/260)
    """生成weight序列"""
    w_list = np.array([w**(N-1-i) for i in range(N)])

    weights = np.repeat(w_list.reshape(N,1),len(changepct.columns),axis = 1)

    rs_list = []
    for i in range(11):
        rs = changepct.loc[changepct.index[-(N+273+i)]: changepct.index[-(273+1+i)]].values * weights
        rs_list.append(-np.nansum(rs * 10000,axis = 0)/np.nansum(weights,axis = 0))
    long_term_relative_strength = np.nanmean(np.stack(rs_list,axis = 0),axis = 0)
    long_term_relative_strength = {k:v for k,v in zip(changepct.columns,long_term_relative_strength)}

    df_res['long_term_relative_strength'] = df_res['secucode'].map(long_term_relative_strength)

    """
    long_term_historical_alpha:
    1、股票收益率 对沪深300收益率，进行时间序列回归，取回归系数，回归时间窗口为1040个交易日，半衰期260个交易日 ；
    2、取回归截距项，之后273个交易日，在11个交易日的时间窗口内取非滞后值等全平均值，最后取相反数,
    """

    N = 1040
    dt_list = get_Njyr(dt,N+11+273)
    changepct = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','changepct')/100
    changepct = np.log(1+ changepct)# 对数收益率

    index_pct_list = np.array(df_300[df_300['tradingday'].isin(dt_list)].sort_values('tradingday')['changepct'])/100
    w = 0.5**(1/260)
    """生成weight序列"""
    w_list = np.array([w**(N-1-i) for i in range(N)])
    # weights = np.repeat(w_list.reshape(N,1),len(changepct.columns),axis = 1)

    alpha_list = []
    for i in range(11):
        x = changepct.loc[changepct.index[-(N+273+i)]: changepct.index[-(273+1+i)]].values
        y = index_pct_list[-(N+273+i):-(273+i)]
        Y = sm.add_constant(y)
        model = sm.WLS(x,Y,w_list)
        result = model.fit()
        alpha_ ,beta_  = result.params
        alpha_list.append(alpha_)

    long_term_historical_alpha = -np.nanmean(np.stack(alpha_list,axis = 0),axis = 0)*10**6
    long_term_historical_alpha = {k:v for k,v in zip(changepct.columns,long_term_historical_alpha)}
    df_res['long_term_historical_alpha'] = df_res['secucode'].map(long_term_historical_alpha)

    """
    short_term_revarsal: 最近一个月的加权累积对数日收益率，时间窗口21个交易日，半衰期5个交易日，T={t-1，.....，t-n},
    """
    N = 21
    dt_list = get_Njyr(dt,N)
    changepct = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','changepct')/100

    w = 0.5**(1/5)
    w_list = np.array([w**(N-1-i) for i in range(N)])
    weights = np.repeat(w_list.reshape(N,1),len(changepct.columns),axis = 1)
    short_term_revarsal = np.nansum(changepct * weights,axis = 0)/ np.nansum(weights,axis=0) * 10000
    short_term_revarsal = {k:v for k,v in zip(changepct.columns,short_term_revarsal)}

    df_res['short_term_revarsal'] = df_res['secucode'].map(short_term_revarsal)

    """
    dr_abs_val_mean_log_20d: 过去20 日（每日涨跌幅绝对值/成交额）的均值取对数,
    """
    N = 20
    dt_list = get_Njyr(dt,N)
    turnovervalue = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','amount')/10000
    changepct = stack2dataframe(df_hq[df_hq['tradingday'].isin(dt_list)].copy(),'tradingday','secucode','changepct')/100

    dr_abs_val_mean_log_20d = np.log(np.mean(abs(changepct)/turnovervalue*100000,axis = 0))
    dr_abs_val_mean_log_20d = {k:v for k,v in zip(changepct.columns,dr_abs_val_mean_log_20d)}

    df_res['dr_abs_val_mean_log_20d'] = df_res['secucode'].map(dr_abs_val_mean_log_20d)

    # df_res[df_res['secucode'].isin(['000001','002001','003000','300001','301000','600000','601001','605001','688001'])].sort_values('secucode')

    df_res.to_csv('df_res_{}.csv'.format(dt),index= None)

import pandas as pd
import numpy as np
import os
import json
import gc
import sys

# from NSCDataProcess import * 
# from NSCOracle import *
# from NSCAlphaHq import *

from sklearn.utils import shuffle
from sklearn.model_selection import train_test_split
import lightgbm as lgb
from sklearn import metrics
from sklearn.metrics import precision_recall_curve
from sklearn.metrics import average_precision_score


g = locals()
cursor,conn = qt_cursor,qt_conn
engine = qt_engine
indexcol,columncol = 'tradingday','secucode'
# start_date = '20210501'
# end_date = '20211231'
# dt_list
# dt = '20210812'
# dt = sys.argv[1]
start_date = '20160101'
end_date = '20211231'

"""new params"""
binary_params = {
    'boosting_type':'gbdt',
    'n_estimators':1000,
    'learning_rate':0.05,
    'max_depth':5,
    'bagging_fraction':1,
    'feature_fraction':1,
    'min_sum_hessian_in_leaf':0.2,
    'lambda_l1':1,
    'lambda_l2':1,
    'metric':'auc'
}


def train_model(train,usefulcols,label_col,params):
    train_ = train.dropna(subset = [label_col],how= 'any')
    print(train_.shape)
    training,testing = train_test_split(train_,test_size=0.2,random_state=2019)
    lgb_train = lgb.Dataset(training[usefulcols],
                            label=list(training[label_col]),
                            #weight=training['weight'],
                            categorical_feature=[],
                            free_raw_data=False)
    lgb_valid = lgb.Dataset(testing[usefulcols],
                            label=list(testing[label_col]),
                            #weight=testing['weight'],
                            categorical_feature=[],
                            reference=lgb_train)
    print("Begin training Model!")
    clf = lgb.train(params, 
                    lgb_train, 
                    valid_sets = [lgb_train,lgb_valid],
                    verbose_eval = 20, 
                    early_stopping_rounds = 10
                   )
    return clf




"""get_all_samples"""
# sql_ = """
# select * 
# from t_pct_d 
# where tradingday between '{start_date}' and '{end_date}'
# """.format(start_date = start_date ,end_date = end_date)
# df_pct = get_data_from_oracle(cursor,sql_)

# df_pct['flag1'] = df_pct['pct_9'].apply(lambda x: 1 if x<=0.7 else 0)
# df_pct['flag2'] = df_pct['dt3s'].apply(lambda x:1 if x>=1 else 0)
# df_pct['flag3'] = df_pct.apply(lambda x:1 if x['pct_10']-x['pct_9']<=-0.0998 else 0,axis = 1)

# df_pct['flag'] = df_pct.apply(
#     lambda x: 1 if np.nansum([x['flag1'],x['flag2']]) >=1.0 else 0,axis = 1 )

# flag  = stack2dataframe(df_pct,'tradingday','secucode','flag')

# 获取label


delta_days = 12
for i in range(delta_days,flag.shape[0]):
    flag.iloc[i-delta_days:i-1,:] = flag.iloc[i-delta_days:i-1,:] + flag.iloc[i-1,:]

df_flag = flag.stack().reset_index().rename(columns={0:'flag_map'})

df_flag['label'] = df_flag['flag_map'].apply(lambda x: 1 if x>0 else 0)

# 获取特征
# 特征处理
# 训练模型

train_start_date = '20160101'
train_end_date = '20201231'
test_start_date = '20210101'
test_end_date = '20211231'

train_data = df_flag[(df_flag['tradingday']>=train_start_date)&(df_flag['tradingday']<=train_end_date)].copy()
test_data = df_flag[(df_flag['tradingday']>=test_start_date)&(df_flag['tradingday']<=test_end_date)].copy()

df_negative = shuffle(train_data[train_data['label']==0])
df_positive = shuffle(train_data[train_data['label']==1])


industry_dict = dict(df_positive['zxfirstindustryname'].value_counts()/df_positive['zxfirstindustryname'].shape[0])

negative_cnt = df_positive.shape[0]*15

# negetive_cnt
negative_samples_list = []
for k in industry_dict.keys():
    negative_samples_list.append(
        df_negative[df_negative['zxfirstindustryname']==k].sample(
            int(negative_cnt*industry_dict[k])))
    

df_negative_sample = pd.concat(negative_samples_list)

df_train = shuffle(pd.concat([df_positive,df_negative_sample]))

df_train = pd.merge(df_train,df_type0,on = ['tradingday','secucode'],how = 'left')
df_test = pd.merge(test_data,df_type0,on = ['tradingday','secucode'],how = 'left')
df_train = pd.merge(df_train,df_type1,on = ['tradingday','secucode'],how = 'left')
df_test = pd.merge(df_test,df_type1,on = ['tradingday','secucode'],how = 'left')
feature_columns = [col for col in df_train.columns if col not in 
    ['tradingday', 'secucode', 'flag_map', 'label', 'zxfirstindustryname','stock_id']]
"""
feature process 
filter_by_median
zscore
"""
for value in feature_null_filter:
    # value = 'pe'
    tmp_ = stack2dataframe(df_train,indexcol,columncol,value)
    tmp_ = filter_by_median(tmp_,5)
    tmp_ = zscore(tmp_)
    df_train = df_train.set_index([indexcol,columncol])
    df_train[value] = tmp_.stack().reset_index()\
        .rename(columns={0:value})\
        .set_index([indexcol,columncol])[value]
    df_train = df_train.reset_index()


"""
feature process 
filter_by_median
zscore
"""
for value in feature_null_filter:
    # value = 'pe'
    tmp_ = stack2dataframe(df_test,indexcol,columncol,value)
    tmp_ = filter_by_median(tmp_,5)
    tmp_ = zscore(tmp_)
    df_test = df_test.set_index([indexcol,columncol])
    df_test[value] = tmp_.stack().reset_index()\
        .rename(columns={0:value})\
        .set_index([indexcol,columncol])[value]
    df_test = df_test.reset_index()

binary_clf = train_model(
        df_train,feature_null_filter,'label',binary_params)

"""train1 model pred"""
binary_y_prob = binary_clf.predict(
    df_test[feature_null_filter], 
    num_iteration=binary_clf.best_iteration)
df_test['score'] = binary_y_prob

df_test = pd.merge(
    df_test,
    df_pct[['tradingday','secucode','flag1','flag2','flag3','flag']],
    on = ['tradingday','secucode'],
    how = 'left')


# 计算fpr、tpr和auc
# label_col = 'flag1'
for label_col in ['flag1','flag','label']:
    fpr, tpr, _ = metrics.roc_curve(df_test[label_col], df_test['score'], pos_label=1)
    roc_auc = metrics.auc(fpr, tpr)
    # 计算recall、precision、average_precision
    precision, recall, _ = precision_recall_curve(df_test[label_col], df_test['score'])
    average_precision = average_precision_score(df_test[label_col], df_test['score'])
    print(label_col,roc_auc)

flag1 0.8428103831231061
flag 0.8297427114760323
label 0.7762148802100935

# 计算fpr、tpr和auc
# label_col = 'flag1'
for label_col in ['flag1','flag','label']:
    fpr, tpr, _ = metrics.roc_curve(df_test[label_col], df_test['score'], pos_label=1)
    roc_auc = metrics.auc(fpr, tpr)
    # 计算recall、precision、average_precision
    precision, recall, _ = precision_recall_curve(df_test[label_col], df_test['score'])
    average_precision = average_precision_score(df_test[label_col], df_test['score'])
    print(label_col,roc_auc)

flag1 0.855135845298343
flag 0.8427709839538905
label 0.789676563188751

df_test_2020 = df_test[(df_test['tradingday']>='20200101')&(df_test['tradingday']<='20201231')].copy()
df_test_2021 = df_test[(df_test['tradingday']>='20210101')&(df_test['tradingday']<='20211231')].copy()

"""train(2016-2019)/test:2020"""
for label_col in ['flag1','flag','label']:
    fpr, tpr, _ = metrics.roc_curve(df_test_2020[label_col], df_test_2020['score'], pos_label=1)
    roc_auc = metrics.auc(fpr, tpr)
    # 计算recall、precision、average_precision
    precision, recall, _ = precision_recall_curve(df_test_2020[label_col], df_test_2020['score'])
    average_precision = average_precision_score(df_test_2020[label_col], df_test_2020['score'])
    print(label_col,roc_auc)

flag1 0.8832947851703239
flag 0.8719950928811795
label 0.814474360586548

"""train(2016-2019)/test:2021"""
for label_col in ['flag1','flag','label']:
    fpr, tpr, _ = metrics.roc_curve(df_test_2021[label_col], df_test_2021['score'], pos_label=1)
    roc_auc = metrics.auc(fpr, tpr)
    # 计算recall、precision、average_precision
    precision, recall, _ = precision_recall_curve(df_test_2021[label_col], df_test_2021['score'])
    average_precision = average_precision_score(df_test_2021[label_col], df_test_2021['score'])
    print(label_col,roc_auc)

flag1 0.7803712037450358
flag 0.7659319455329601
label 0.7223378752014169

"""train(2016-2020)/test:2021"""
for label_col in ['flag1','flag','label']:
    fpr, tpr, _ = metrics.roc_curve(df_test_2021[label_col], df_test_2021['score'], pos_label=1)
    roc_auc = metrics.auc(fpr, tpr)
    # 计算recall、precision、average_precision
    precision, recall, _ = precision_recall_curve(df_test_2021[label_col], df_test_2021['score'])
    average_precision = average_precision_score(df_test_2021[label_col], df_test_2021['score'])
    print(label_col,roc_auc)

flag1 0.8428103831231061
flag 0.8297427114760323
label 0.7762148802100935

binary_clf.save_model('model_2016_2019.txt')
binary_clf.save_model('model_2016_2020.txt')
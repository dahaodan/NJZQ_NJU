import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from NSCOracle import *
from NSCDataProcess import * 
from  NSCAlphaHq import *
from NSCAlphaSysmbolFunctions import *
from NSCDeapFitness import *

from deap import algorithms
from deap import base
from deap import creator
from deap import tools
from deap import gp
import itertools 
import operator


start_date = '20200101'
end_date = '20201231'
"""fitness define"""
version_key = "IR"

indexcol = 'dt'
columncol = 'stock_id'


g = locals()
# 获取行情数据
df_hq = 
# 计算收益
# pctret =
g['pctret'] = (g['openprice'].shift(-2)/g['openprice'].shift(-1))-1


def filter_by_median(df,N):
    """
    # 按行求dt的中位数；再按列减去中位数，再按行求差的中位数；
    # condition1 = Fm - N*Fm1 condition2 = Fm + N*Fm1 
    """
    dfmedian = df.sub(df.median(axis=1),axis=0).abs().median(axis=1)
    condition1 = df.sub((df.median(axis=1) + N*dfmedian),axis=0)
    condition2 = df.sub((df.median(axis=1) - N*dfmedian),axis=0)
    dfcond1 = pd.DataFrame(
        np.repeat(np.array(df.median(axis=1) + N*dfmedian),
                  df.shape[1]).reshape(df.shape[0],df.shape[1]),
        index = df.index,columns = df.columns)
    dfcond2 = pd.DataFrame(
        np.repeat(np.array(df.median(axis=1) - N*dfmedian),
                  df.shape[1]).reshape(df.shape[0],df.shape[1]),
        index = df.index,columns = df.columns)
    dffilter2 = pd.DataFrame(
        np.where(condition2 < 0 ,dfcond2,df),
        index = df.index ,
        columns = df.columns)
    dffilter1 = pd.DataFrame(
        np.where(condition1 > 0 ,dfcond1,dffilter2),
        index = df.index ,
        columns = df.columns)
    return dffilter1


def filter_inf(df):
    """filter_inf by np.nan"""
    df = df.replace([float("inf"),float("-inf")],np.nan)
    return df


def zscore(df):
    """zscore pivot df"""
    return (df.sub(df.mean(axis = 1),axis = 0))\
              .div(df.std(axis = 1)[df.std(axis=1).values != 0],axis = 0)


#加
def ADD(left,right):
    left.replace(to_replace=[None],value=np.nan,inplace = True)
    right.replace(to_replace=[None],value=np.nan,inplace = True)
    return left.add(right)


#减
def SUB(left,right):
    left.replace(to_replace=[None],value=np.nan,inplace = True)
    right.replace(to_replace=[None],value=np.nan,inplace = True)
    return left.sub(right)

#除
def DIV(left,right):
    left.replace(to_replace=[None],value=np.nan,inplace = True)
    right.replace(to_replace=[None],value=np.nan,inplace = True)
    return left.div(right)


#乘
def MUL(left,right):
    left.replace(to_replace=[None],value=np.nan,inplace = True)
    right.replace(to_replace=[None],value=np.nan,inplace = True)
    return left.mul(right)


def IR(pred,pctret):
    """
    return: IR 
    pred: pivot functions result
    pctret: pivot pctret
    """
    pred = pred.replace([float("inf"),float("-inf")],np.nan)
    pred = pred.dropna(how = 'all',axis = 0)
    factor_rank = pred.rank(axis=1)
    cor = factor_rank.corrwith(pctret.rank(axis=1),axis=1)
    res_mean = cor.mean()
    res_std = cor.std()
    if res_std == 0:
        return 0 
    else:
        return np.round(np.abs(res_mean/res_std),5)

"""pivot数据预处理"""
for value in [col for col in g['Feature_cols'] if col not in ['adjfactor']]:
    # print(value)
    g[value] = g[value].apply(lambda x:filter_by_median(x,5),axis =1)
    g[value] = filter_inf(g[value])
    g[value] = zscore(g[value])

df_pctret = pctret.stack().reset_index().rename(
        columns = {'level_1':'stock_id',0:'pctret'})

"""deap begin=================================================================="""
ColNum = len([col for col in Feature_cols if col !='adjfactor'])
pset = gp.PrimitiveSetTyped("MAIN", itertools.repeat(pd.DataFrame, ColNum), pd.DataFrame)

pset.addPrimitive(ADD, [pd.DataFrame,pd.DataFrame],pd.DataFrame)
pset.addPrimitive(SUB, [pd.DataFrame,pd.DataFrame],pd.DataFrame)
pset.addPrimitive(MUL, [pd.DataFrame,pd.DataFrame],pd.DataFrame)
pset.addPrimitive(DIV, [pd.DataFrame,pd.DataFrame],pd.DataFrame)
pset.addPrimitive(int_2,[],int)
pset.addPrimitive(int_3,[],int)
pset.addPrimitive(int_4,[],int)
pset.addPrimitive(int_5,[],int)
pset.addPrimitive(int_9,[],int)
pset.addPrimitive(int_10,[],int)
pset.addPrimitive(int_11,[],int)
pset.addPrimitive(int_13,[],int)
pset.addPrimitive(int_14,[],int)
pset.addPrimitive(int_20,[],int)
pset.addPrimitive(int_21,[],int)
pset.addEphemeralConstant("const0",lambda: random.randint(2,25), int)#生成指定范围内的整数


pset.renameArguments(ARG0='openprice')
pset.renameArguments(ARG1='closeprice')
pset.renameArguments(ARG2='highprice')
pset.renameArguments(ARG3='lowprice')
pset.renameArguments(ARG4='amount')
pset.renameArguments(ARG5='value')
pset.renameArguments(ARG6='vwap')



def evalSymbReg(
    individual,pctret,
    openprice,closeprice,highprice,lowprice,amount,value,vwap):
    """fitness function RECALL"""
    function = toolbox.compile(expr=individual)
    pred = function(
        openprice,closeprice,highprice,lowprice,amount,value,vwap )
    ir_ = IR(pred,pctret)
    return np.round(ir_,5),

creator.create("FitnessMax", base.Fitness, weights=(1.0,))
creator.create("Individual", gp.PrimitiveTree, fitness=creator.FitnessMax)
toolbox = base.Toolbox()
toolbox.register("expr", gp.genHalfAndHalf, pset=pset, min_=2, max_=6)
toolbox.register("individual", tools.initIterate, creator.Individual, toolbox.expr)
toolbox.register("population", tools.initRepeat, list, toolbox.individual)
toolbox.register("compile", gp.compile, pset=pset)

toolbox.register(
    "evaluate", evalSymbReg,
    pctret=pctret,
    openprice=openprice,closeprice=closeprice,highprice=highprice,lowprice=lowprice,amount=amount,value=value,vwap=vwap)

toolbox.register("select", tools.selTournament, tournsize=4)
toolbox.register("mate", gp.cxOnePoint)
toolbox.register("expr_mut", gp.genFull, min_=2, max_=6)
toolbox.register("mutate", gp.mutUniform, expr=toolbox.expr_mut, pset=pset)
toolbox.decorate("mate", gp.staticLimit(key=operator.attrgetter("height"), max_value=4))
toolbox.decorate("mutate", gp.staticLimit(key=operator.attrgetter("height"), max_value=4))

IND_SIZE = 100
pop = toolbox.population(n=IND_SIZE)
hof = tools.HallOfFame(1)
# hof = tools.HallOfFame(5)

stats_fit = tools.Statistics(lambda ind: ind.fitness.values)
#stats用来汇报结果
stats_size = tools.Statistics(len)
mstats = tools.MultiStatistics(fitness=stats_fit, size=stats_size)
mstats.register("avg", np.nanmean)
mstats.register("std", np.nanstd)
mstats.register("min", np.nanmin)
mstats.register("max", np.nanmax)

pop, log = algorithms.eaSimple(
    pop, toolbox, 0.7, 0.2,3, stats=mstats,halloffame=hof, verbose=True)

top = tools.selBest(pop, k = IND_SIZE)

alpha_expr = []
fitness_v = []

for i in range(len(top)):
    if top[i].fitness.values[0]>0:
        alpha_expr.append(top[i])
        fitness_v.append(top[i].fitness.values)
#     print("alpha{0} expression is: {1},and the fitness is {2} ".format(i,top[i],top[i].fitness.values))

f = open("./{}_{}_{}.txt".format(version_key,start_date,end_date), "w")
res_fit = sorted(list(set(fitness_v)),reverse=True)
for i in res_fit:
    f_index = fitness_v.index(i)
    print("alpha{}={} # {} \n".format(res_fit.index(i),alpha_expr[f_index],i))
    f.write("alpha{}={} # {} \n".format(res_fit.index(i),alpha_expr[f_index],i))
f.close()
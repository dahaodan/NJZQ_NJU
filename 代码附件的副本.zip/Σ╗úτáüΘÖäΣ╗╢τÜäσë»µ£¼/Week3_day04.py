import pandas as pd
import numpy as np
import time 
import sys



import warnings
warnings.filterwarnings("ignore")

# dt = time.strftime('%Y%m%d', time.localtime())
dt = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
# dt = sys.argv[1]
print(dt)

